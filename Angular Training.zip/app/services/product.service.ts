import {Product} from "../models/product.model"
import { Injectable } from "@angular/core";
import { Http, Headers, RequestOptions } from "@angular/http";

@Injectable()
export class ProductService{
    
    private productsData: Product[] = [];
    restUrl = "http://localhost:2403/wsproducts"
    myHeaders = new Headers({'Content-Type':'application/json'})
    options= new RequestOptions({headers: this.myHeaders})

    constructor(private ht:Http){
      /*  this.productsData =  [new Product(1,"Nokia 3",6000,"Nokia smart phone"),
        new Product(2,"Hitachi AC",35000,"Hitachi window AC"),
        new Product(3,"Sony TV",30000,"Sony LED TV"),
        new Product(4,"iphone",76000,"iphone7")] */

    }

    getProducts(){
        //return this.productsData;
        return this.ht.get(this.restUrl);

    }

    addProduct(newProduct:Product){
        return this.ht.post(this.restUrl, newProduct, this.options)
    }

    deleteProduct(id){
        return this.ht.delete(this.restUrl+"/"+id)
    }
}