import {Component} from '@angular/core'
import {Product} from "../models/product.model"
import { CartItem } from "../models/cartitem.model";
import {ProductService} from "../services/product.service"
import { CartService } from "../services/cart.service";

@Component({
    selector: "product-list",
    templateUrl: "./product-list.component.html"
})

export class ProductListComponent{
    products:Product[] = [];

    constructor(private cs:CartService, private ps:ProductService){
       // let ps:ProductService = new ProductService();
        //this.products=ps.getProducts();
        ps.getProducts().subscribe(
          (resp) => this.products = resp.json(),
          (err) => console.log("Get Error", err)
        )
    }

    addToCart(selectedProduct:Product){
        this.cs.addCartItem(new CartItem(selectedProduct.name,selectedProduct.price,1));
    }
}