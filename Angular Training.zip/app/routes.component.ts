import { Component } from "@angular/core"
import { ProductService } from "./services/product.service";
import { Product } from "./models/product.model";

@Component({
    template: `<h3>Welcome To Shopping
            <br> Price Value is {{price | currency:'INR' | lowercase}}
            <br> {{myDate | date:"MM/dd/yyyy"}}
            </h3>`
})
export class HomeComponent {
    price: number = 110.354;
    myDate = new Date();
}

@Component({
    template: `<div class="col-sm-6">
        <product-list></product-list>
    </div>
    <div class="col-sm-6 well">
        <cart-items></cart-items>
    </div>`
})
export class ListComponent {}

@Component({
    template: "<h3 class='well'>404. Oops!! Not Found</h3>"
})
export class NotFoundComponent {}

@Component({
    templateUrl: "./manage.component.html"
})
export class ManageComponent {
    mgProducts:Product[] = []
    frmProduct: Product = new Product("","",0,"");
    temp = -1;
    constructor(private psvc:ProductService){
      //  this.mgProducts = psvc.getProducts();
      psvc.getProducts().subscribe(
          (resp) => this.mgProducts = resp.json(),
          (err) => console.log("Get Error", err)
      )
    }

    save() {
        this.psvc.addProduct(this.frmProduct).subscribe(
            (data) => {
            //if(this.frmProduct.id == undefined){
            if(this.temp = -1){
                this.mgProducts.push(data.json())
            } else {
                this.mgProducts[this.temp] = data.json();
                this.temp = -1;
            }
            },
            (err) => console.log("Save Error",err)
        )
        this.frmProduct = new Product("","",0,"");
    }

    delete(id,idx) {
        this.psvc.deleteProduct(id).subscribe(
            (data) => this.mgProducts.splice(idx,1),
            (err) => console.log("Delete Error",err)
        )
    }

    edit(product,idx){
        this.frmProduct = Object.assign({},product);
        this.temp = idx;
    }
}